package com.kd.cube.util;

public class Math {

}
